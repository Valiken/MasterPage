﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Project4
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                cnn.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                cnn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "SELECT * FROM  Comments";
                cmd.Connection = cnn;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Comments");
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataRow drow = ds.Tables["Comments"].NewRow();
                drow["name"] = nameField.Text; 
                 drow["company"] = companyField.Text;
                drow["email"] = emailField.Text;
                drow["comment"] = commentField.Text;
                drow["rating"] = ratingList.SelectedValue;
                ds.Tables["Comments"].Rows.Add(drow);
                da.Update(ds, "Comments");

                comfMessage.Visible = true;
            }
            catch(Exception ex)
            {}
            }
        }
    }
