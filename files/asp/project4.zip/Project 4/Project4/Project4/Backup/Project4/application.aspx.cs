﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Project4
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
        }


        protected void Sort_By(object sender, EventArgs e)
        {
            try
            {

                String expression = "";
                SortDirection direction;

                // Create the sort expression from the values selected 
                // by the user from the DropDownList controls. Multiple
                // columns can be sorted by creating a sort expression
                // that contains a comma-separated list of field names.
                expression = DropDownList1.SelectedValue + "," + DropDownList2.SelectedValue;

                //  Determine the sort direction. The sort direction
                // applies only to the second column sorted.
                switch (DirectionList.SelectedValue)
                {
                    case "Ascending":
                        direction = SortDirection.Ascending;
                        break;
                    case "Descending":
                        direction = SortDirection.Descending;
                        break;
                    default:
                        direction = SortDirection.Ascending;
                        break;
                }

                // Use the Sort method to programmatically sort the GridView
                // control using the sort expression and direction.
                GridView1.Sort(expression, direction);
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                GridView1.DataBind();
            }
        }

    }
}