<!DOCTYPE HTML>
<html>

<head>
  <title>Contact Me</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
  <script src="http://html5form.googlecode.com/svn/trunk/jquery.html5form-1.5-min.js"></script>
  <script src="js/contact.js"></script> 
</head>

<body>
  <div id="main">
    <header>
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">Brian<span class="logo_colour">Berg</span></a></h1>
          <h2>Striving to meet your business needs.</h2>
        </div>
      </div>
      <nav>
        <div id="menu_container">
            <ul class="sf-menu" id="nav">
            <li><a href="index.html">Home</a></li>
            <li><a href="resume.html">Resume</a></li>
            <li><a href="family.html">Family</a></li>
			 <li><a href="hobbies.html">Hobbies & Interests</a></li>
            <li><a href="#">My Work</a>
              <ul>
				<li><a href="#">CSUPomona Work</a></li>
                <li><a href="scrum/index.html">CIS 231 Scrum Website</a></li>
                <li><a href="cis304/cis304.html">CIS 304 Java Applet</a>
                </li>
               <!-- <li><a href="#">CIS 305 Database</a>
				 <ul>
                    <li><a href="#">Project 1</a></li>
                    <li><a href="#">Project 2</a></li>
                  </ul>
				</li>
                <li><a href="#">USCC CyberQuest Certificate</a></li>-->
              </ul>
            </li>
			<li><a href="aboutme.html">About Me</a></li>
            <li><a href="contact.html">Contact Me</a></li>
          </ul>
        </div>
      </nav>
    </header>
    <div id="site_content">
      <div id="sidebar_container">
        <div class="sidebar">

        </div>
      </div>
      <div class="content">
		<?php
		//setup parameters
				
		$name = $_REQUEST['name'];
		$email = $_REQUEST['email'] ;
		$subject = 'Enquiry from your site';
		$company = $_REQUEST['company'];
		$message = $_REQUEST['comment'] ;
		mail("dachsund@dslextreme.com", $subject,
		$message, "From:" . $email);
		echo "Thank you for using our mail form!";		
		?>
      
	  
	  </div>
      </div>
    </div>
    <footer>
      <p>Copyright &copy; Brian Berg | <a href="http://www.css3templates.co.uk">design from css3templates.co.uk</a></p>
    </footer>
  </div>
  <p>&nbsp;</p>
  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/jquery.easing-sooper.js"></script>
  <script type="text/javascript" src="js/jquery.sooperfish.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('ul.sf-menu').sooperfish();
    });
  </script>
</body>
</html>