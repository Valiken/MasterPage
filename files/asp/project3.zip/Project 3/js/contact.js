    $(document).ready(function(){
        $('#contact_form').html5form();  
				allBrowsers : true,
				responseDiv : '#response',
				messages: 'en',
				messages: 'es',
				method : 'GET',
				colorOn :'#6b6764',
				colorOff :'#0d85a5'
    });