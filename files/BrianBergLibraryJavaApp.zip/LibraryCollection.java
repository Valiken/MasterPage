import java.util.HashMap;

public class LibraryCollection
{
	public HashMap<String, Item> collection = new HashMap <String, Item>();
	
	LibraryCollection()
	{
		try
		{		
			File file = new File("items.txt");
			Scanner buffer = new Scanner(file);
			String line = buffer.nextLine();
			String[] inputs = line.split(",");
			Item item = new Item();
			if(inputs[2] = "Book")
			{
				item.ID = inputs[0
				item
			}

			
			collection.put(item.ID, item);
			line = buffer.nextLine();
			
		}
		catch (IOException e)
		{
		
		}
	}
	
	// Return an item from the collection
	Item getItem(String ID)
	{
		return collection.get(ID);
	}

}