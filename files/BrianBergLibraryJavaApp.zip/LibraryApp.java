public class LibraryApp 
{
	public static void main(String[] args) 
	{
		new LibraryFrame();
	}
}
