import java.io.*;
import java.util.*;

// A collection of library items
public class BorrowerCollection 
{
	HashMap <String, Borrower> borrowerList = new HashMap <String, Borrower>();
	
	BorrowerCollection()
	{
	
		try
		{		
			File file = new File("borrowers.txt");
			Scanner buffer = new Scanner(file);
			String line = buffer.nextLine();
			String[] inputs = line.split(",");
			Borrower borrowers = new Borrower();
			borrowers.ID = inputs[0];
			borrowers.name = inputs[1];
			
			borrowerList.put(borrowers.ID, borrowers);
			line = buffer.nextLine();
			
		}
		catch (IOException e)
		{
		
		}
	}
	
	// Return an item from the collection
	
	Borrower getBorrower(String ID)
	{
		return borrowerList.get(ID);
	}

}
